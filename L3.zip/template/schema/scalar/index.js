module.exports = `
    scalar Moment
`;