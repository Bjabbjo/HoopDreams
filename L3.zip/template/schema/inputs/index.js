const pickupGameInput = require("./pickupGameInput");
const playerInput = require("./playerInput");
const signupPlayerInput = require("./signupPlayerInput");

module.exports = `
    ${pickupGameInput}
    ${playerInput}
    ${signupPlayerInput}    
`;