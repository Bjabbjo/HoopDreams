module.exports = `
    input SignupPlayerInput {
        playerId: String!
        pickupGameId: String!
    }
`;